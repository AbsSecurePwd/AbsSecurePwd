package fr.paris.lutece.portal.business.role;

public interface AdminWorkgroupResource {

	String getWorkgroup();

}

package fr.paris.lutece.portal.business.sql.driver;

import fr.paris.lutece.portal.business.dashboard.AdminDashboardDAO;
import fr.paris.lutece.portal.business.dashboard.DashboardDAO;
import fr.paris.lutece.portal.business.dashboard.IAdminDashboardDAO;
import fr.paris.lutece.portal.business.dashboard.IDashboardDAO;
import fr.paris.lutece.portal.business.datastore.DataEntityDAO;
import fr.paris.lutece.portal.business.datastore.IDataEntityDAO;
import fr.paris.lutece.portal.business.file.FileDAO;
import fr.paris.lutece.portal.business.file.IFileDAO;
import fr.paris.lutece.portal.business.globalmanagement.IRichTextEditorDAO;
import fr.paris.lutece.portal.business.globalmanagement.RichTextEditor;
import fr.paris.lutece.portal.business.globalmanagement.RichTextEditorDAO;
import fr.paris.lutece.portal.business.mail.IMailItemQueueDAO;
import fr.paris.lutece.portal.business.mail.MailItemQueueDAO;
import fr.paris.lutece.portal.business.mailinglist.IMailingListDAO;
import fr.paris.lutece.portal.business.mailinglist.MailingListDAO;
import fr.paris.lutece.portal.business.page.IPageDAO;
import fr.paris.lutece.portal.business.page.PageDAO;
import fr.paris.lutece.portal.business.physicalfile.IPhysicalFileDAO;
import fr.paris.lutece.portal.business.physicalfile.PhysicalFile;
import fr.paris.lutece.portal.business.physicalfile.PhysicalFileDAO;
import fr.paris.lutece.portal.business.right.FeatureGroup;
import fr.paris.lutece.portal.business.right.FeatureGroupDAO;
import fr.paris.lutece.portal.business.right.IFeatureGroupDAO;
import fr.paris.lutece.portal.business.right.ILevelDAO;
import fr.paris.lutece.portal.business.right.IRightDAO;
import fr.paris.lutece.portal.business.right.LevelDAO;
import fr.paris.lutece.portal.business.right.RightDAO;
import fr.paris.lutece.portal.business.role.IRoleDAO;
import fr.paris.lutece.portal.business.role.RoleDAO;
import fr.paris.lutece.portal.business.search.ISearchParameterDAO;
import fr.paris.lutece.portal.business.search.SearchParameterDAO;
import fr.paris.lutece.portal.business.stylesheet.IStyleSheetDAO;
import fr.paris.lutece.portal.business.stylesheet.StyleSheetDAO;
import fr.paris.lutece.portal.business.template.DatabaseTemplateDAO;
import fr.paris.lutece.portal.business.template.IDatabaseTemplateDAO;
import fr.paris.lutece.portal.business.user.AdminUserDAO;
import fr.paris.lutece.portal.business.user.IAdminUserDAO;
import fr.paris.lutece.portal.business.user.attribute.AdminUserFieldDAO;
import fr.paris.lutece.portal.business.user.attribute.AttributeDAO;
import fr.paris.lutece.portal.business.user.attribute.IAdminUserFieldDAO;
import fr.paris.lutece.portal.business.user.attribute.IAttributeDAO;
import fr.paris.lutece.portal.business.workgroup.AdminWorkgroup;
import fr.paris.lutece.portal.business.workgroup.AdminWorkgroupDAO;
import fr.paris.lutece.portal.business.workgroup.IAdminWorkgroupDAO;
import fr.paris.lutece.portal.business.xsl.IXslExportDAO;
import fr.paris.lutece.portal.business.xsl.XslExportDAO;

public class DriverClass {

	public static void main(String[] args) {
		
		IAdminUserDAO _dao = new AdminUserDAO();
	   	_dao.checkAccessCodeAlreadyInUse("123");
	   	_dao.checkRoleAttributed("222");
	   	_dao.checkEmailAlreadyInUse("email");
	   	_dao.countUserPasswordHistoryFromDate(null, 23);
	   	_dao.delete(23);
	   	_dao.deleteAllDelegatedRightsForUser(23, 1);
	   	_dao.deleteAllOwnRightsForUser(21, 1);
	   	_dao.deleteAllRightsForUser(21);
	   	_dao.deleteAllRolesForUser(21);
	   	_dao.deleteRightForUser(21, "");
	   	_dao.deleteRoleForUser(21, "");
	   	_dao.findAllExpiredUserId();
	   	_dao.getIdUsersToSendFirstAlert(null);
	   	_dao.getIdUsersToSendOtherAlert(null, null, 5);
	   	_dao.getIdUsersWithExpiredLifeTimeList(null);
	   	_dao.getIdUsersWithExpiredPasswordsList(null);
	   	_dao.hasRight(23, "");
	   	_dao.hasRole(23, "");
		
		_dao.insert(null);
		_dao.insert(null);
		_dao.insertNewPasswordInHistory(null, 23);
		_dao.insertRightsListForUser(23, "");
		_dao.insertRolesListForUser(23, "");
		_dao.load(23);
		_dao.loadDefaultAdminUser(23);
		_dao.removeAllPasswordHistoryForUser(23);
		_dao.selectRolesListForUser(23);
		_dao.selectRightsListForUser(23);
		_dao.selectUserByAccessCode("");
		_dao.selectUserByEmail("");
		_dao.selectUserList();
		_dao.selectUserPasswordHistory(23);
		_dao.selectUsersByFilter(null);
		_dao.selectUsersByLevel(23);
		_dao.selectUsersByRight("");
		_dao.selectUsersByRole("");
		 
	
		/*
		 * IXslExportDAO xslExp = new XslExportDAO(); xslExp.delete(11);
		 * xslExp.insert(null); xslExp.load(11); xslExp.selectList();
		 * xslExp.selectListByPlugin(null); //stringbuilder xslExp.store(null);
		 * 
		 * IPhysicalFileDAO phyFile = new PhysicalFileDAO(); phyFile.delete(11);
		 * phyFile.insert(null); phyFile.load(11); phyFile.store(null);
		 * phyFile.newPrimaryKey();
		 * 
		 * IPageDAO iPageDAO = new PageDAO(); iPageDAO.checkPageExist(11);
		 * iPageDAO.delete(11); iPageDAO.getPagesByRoleKey(""); iPageDAO.getPagesList();
		 * iPageDAO.insert(null); iPageDAO.invalidatePage(11); iPageDAO.load(11, true);
		 * iPageDAO.loadImageResource(111); iPageDAO.loadLastModifiedPage();
		 * iPageDAO.loadPageByIdPortlet(121); iPageDAO.loadWithoutImageContent(233,
		 * true); iPageDAO.selectAllPages(); iPageDAO.selectChildPages(23);
		 * iPageDAO.selectChildPagesMinimalData(232);
		 * iPageDAO.selectNewChildPageOrder(121);
		 * iPageDAO.selectPageForChangeAutorisationNode(232); iPageDAO.store(null);
		 * iPageDAO.updateAutorisationNode(232, 433); //stringbuilder
		 * 
		 * IMailingListDAO mailDAO = new MailingListDAO(); mailDAO.checkFilter(null,
		 * 22); mailDAO.delete(232); mailDAO.deleteFilter(null, 23);
		 * mailDAO.insert(null); mailDAO.load(323); mailDAO.insertFilter(null, 232);
		 * mailDAO.selectAll(); mailDAO.selectByFilter(null);
		 * mailDAO.selectByWorkgroup("WG"); mailDAO.store(null);
		 * 
		 * IMailItemQueueDAO mailItem = new MailItemQueueDAO(); mailItem.delete(232);
		 * //two queries in transaction mailItem.getCountMailItem();
		 * mailItem.insert(null); //bytearray mailItem.load(232);
		 * mailItem.lockMailItemQueue(323); mailItem.nextMailItemQueueId();
		 * 
		 * IRichTextEditorDAO richTextEditor = new RichTextEditorDAO();
		 * richTextEditor.findEditors(true);
		 * 
		 * IFileDAO ifileDAO = new FileDAO(); ifileDAO.delete(232);
		 * ifileDAO.insert(null); ifileDAO.load(23432); ifileDAO.newPrimaryKey();
		 * ifileDAO.store(null);
		 * 
		 * IDataEntityDAO idataEnty = new DataEntityDAO(); idataEnty.delete("32");
		 * idataEnty.insert(null); idataEnty.load("232");
		 * idataEnty.selectEntitiesList(); idataEnty.store(null);
		 * 
		 * IAdminDashboardDAO iAdminDashBoard = new AdminDashboardDAO();
		 * iAdminDashBoard.delete("232"); iAdminDashBoard.deleteAll();
		 * iAdminDashBoard.insert(null); iAdminDashBoard.load("232");
		 * iAdminDashBoard.selectAllDashboardComponents();
		 * iAdminDashBoard.selectColumns();
		 * iAdminDashBoard.selectDashboardComponents(null);
		 * iAdminDashBoard.selectMaxOrder(); iAdminDashBoard.selectMaxOrder(2343);
		 * iAdminDashBoard.store(null);
		 * 
		 * 
		 * IDashboardDAO idashBoard = new DashboardDAO(); idashBoard.delete("232");
		 * idashBoard.deleteAll(); idashBoard.insert(null); idashBoard.load("");
		 * idashBoard.selectAllDashboardComponents(); idashBoard.selectColumns();
		 * idashBoard.selectDashboardComponents(null); idashBoard.selectMaxOrder();
		 * idashBoard.selectMaxOrder(22); idashBoard.store(null);
		 * 
		 * 
		 * 
		 * IRightDAO rightDAO = new RightDAO(); rightDAO.delete("");
		 * rightDAO.insert(null); rightDAO.load("");
		 * rightDAO.selectExternalRightsList(2); rightDAO.selectRightsList();
		 * rightDAO.selectRightsList(22); rightDAO.selectRightsList("");
		 * rightDAO.store(null);
		 * 
		 * ILevelDAO iLevelDAO = new LevelDAO(); iLevelDAO.delete(22);
		 * iLevelDAO.insert(null); iLevelDAO.load(22); iLevelDAO.selectLevelsList();
		 * iLevelDAO.store(null);
		 * 
		 * IFeatureGroupDAO featureGrp = new FeatureGroupDAO(); featureGrp.delete("");
		 * featureGrp.insert(null); featureGrp.load("");
		 * featureGrp.selectFeatureGroupsCount(); featureGrp.selectFeatureGroupsList();
		 * featureGrp.store(null);
		 * 
		 * IRoleDAO roleDAO = new RoleDAO(); roleDAO.delete(""); roleDAO.insert(null);
		 * roleDAO.load(""); roleDAO.selectAll(); roleDAO.selectRolesList();
		 * roleDAO.store(null);
		 * 
		 * ISearchParameterDAO iSearchPara = new SearchParameterDAO();
		 * iSearchPara.findAll(); iSearchPara.load("key");
		 * iSearchPara.selectParametersList(); iSearchPara.store(null);
		 * 
		 * IStyleSheetDAO iStyle = new StyleSheetDAO(); //inspect class
		 * iStyle.delete(11); iStyle.insert(null); iStyle.load(232);
		 * iStyle.selectModeId(11); iStyle.selectStyleSheetList(344);
		 * iStyle.selectStyleSheetNbPerStyleMode(22, 11); iStyle.store(null);
		 * 
		 * IAdminWorkgroupDAO iAdminWorkingGrp = new AdminWorkgroupDAO();
		 * iAdminWorkingGrp.checkExistWorkgroup("key");
		 * iAdminWorkingGrp.checkUserHasWorkgroup(22); iAdminWorkingGrp.delete("key");
		 * iAdminWorkingGrp.deleteAllUsersForWorkgroup("key");
		 * iAdminWorkingGrp.deleteUserFromWorkgroup(22, "key");
		 * iAdminWorkingGrp.getUsersListForWorkgroup("key");
		 * iAdminWorkingGrp.getUserWorkgroups(22); iAdminWorkingGrp.insert(null);
		 * iAdminWorkingGrp.insertUserForWorkgroup(null, "key");
		 * iAdminWorkingGrp.isUserInWorkgroup(22, "key"); iAdminWorkingGrp.load("11");
		 * iAdminWorkingGrp.selectWorkgroupList();
		 * iAdminWorkingGrp.selectWorkgroupsByFilter(null);
		 * iAdminWorkingGrp.store(null);
		 * 
		 * IAttributeDAO attrDAO = new AttributeDAO(); attrDAO.delete(22);
		 * attrDAO.insert(null); attrDAO.load(22, null); attrDAO.selectAll(null);
		 * attrDAO.selectCoreAttributes(null); attrDAO.selectPluginAttributes("", null);
		 * attrDAO.store(null);
		 * 
		 * IAdminUserFieldDAO adminUsrDAO = new AdminUserFieldDAO();
		 * adminUsrDAO.delete(11); adminUsrDAO.deleteUserFieldsFromIdAttribute(33);
		 * adminUsrDAO.deleteUserFieldsFromIdField(22);
		 * adminUsrDAO.deleteUserFieldsFromIdUser(90); adminUsrDAO.insert(null);
		 * adminUsrDAO.load(22); adminUsrDAO.selectByFilter(null); //inspect
		 * adminUsrDAO.selectUserFieldsByIdUserIdAttribute(22, 33); //inspect
		 * adminUsrDAO.selectUsersByFilter(null); adminUsrDAO.store(null);
		 * 
		 * 
		 * IDatabaseTemplateDAO dbTemplate = new DatabaseTemplateDAO();
		 * dbTemplate.getTemplateFromKey("22"); dbTemplate.updateTemplate("1", "2");
		 */

	}

}

package fr.paris.lutece.portal.service.includes;

public class MokeHttpServletRequest {

}

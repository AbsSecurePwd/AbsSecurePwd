package fr.paris.lutece.portal.service.rbac;

public interface RBACResource {

}

package fr.paris.lutece.portal.business.user.authentication;

public enum PassEnum {
	   CLEARTEXT, STORABLE
	
}

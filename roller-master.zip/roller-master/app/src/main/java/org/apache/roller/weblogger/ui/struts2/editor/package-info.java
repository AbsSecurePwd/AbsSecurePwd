/**
 * Struts 2 action classes for editor UI.
 */
package org.apache.roller.weblogger.ui.struts2.editor;
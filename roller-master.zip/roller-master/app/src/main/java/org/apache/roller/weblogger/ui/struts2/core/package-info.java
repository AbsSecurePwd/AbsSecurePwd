/**
 * Struts 2 action classes for core UI: main menu, login, etc.
 */
package org.apache.roller.weblogger.ui.struts2.core;
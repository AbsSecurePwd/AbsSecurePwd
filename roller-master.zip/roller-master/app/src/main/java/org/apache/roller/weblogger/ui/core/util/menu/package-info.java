/**
 * XML driven menu system
 */
package org.apache.roller.weblogger.ui.core.util.menu;
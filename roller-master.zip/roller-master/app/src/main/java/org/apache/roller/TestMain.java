package org.apache.roller;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.roller.planet.business.PlanetManager;
import org.apache.roller.planet.business.jpa.JPAPlanetManagerImpl;
import org.apache.roller.planet.pojos.Subscription;
import org.apache.roller.planet.tasks.RefreshPlanetTask;
import org.apache.roller.weblogger.business.WebloggerFactory;
import org.apache.roller.weblogger.business.jpa.JPAPersistenceStrategy;
import org.apache.roller.weblogger.business.pings.PingQueueTask;
import org.apache.roller.weblogger.business.runnable.ResetHitCountsTask;
import org.apache.roller.weblogger.business.runnable.ScheduledEntriesTask;
import org.apache.roller.weblogger.ui.rendering.model.SiteModel;
import org.apache.roller.weblogger.ui.rendering.servlets.CommentAuthenticatorServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.CommentServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.FeedServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.MediaResourceServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.PageServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.PlanetFeedServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.PreviewResourceServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.PreviewServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.RSDServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.ResourceServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.SearchServlet;
import org.apache.roller.weblogger.ui.rendering.servlets.TrackbackServlet;

public class TestMain {
	
	public static void main(String[] args) throws RollerException, IOException, ServletException {
		CommentAuthenticatorServlet commentAuthenticatorServlet = new CommentAuthenticatorServlet();
		commentAuthenticatorServlet.doGet(null, null); // 2
		
		CommentServlet commentServlet = new CommentServlet();
		commentServlet.doGet(null, null); //74
		commentServlet.doPost(null, null);// 73
		
		FeedServlet feedServlet = new FeedServlet();
		feedServlet.doGet(null, null);// 102
		
		MediaResourceServlet mediaResourceServlet = new MediaResourceServlet();
		mediaResourceServlet.doGet(null, null);// 105
		
		PageServlet pageServlet = new PageServlet();
		pageServlet.doGet(null, null);//140
		pageServlet.doPost(null, null);//141
		
		PlanetFeedServlet planetFeedServlet = new PlanetFeedServlet();
		planetFeedServlet.doGet(null, null);// 152
		
		PreviewResourceServlet previewResourceServlet = new PreviewResourceServlet();
		previewResourceServlet.doGet(null, null);// 156
		
		PreviewServlet previewServlet = new PreviewServlet();
		previewServlet.doGet(null, null);//201
		
		ResourceServlet resourceServlet = new ResourceServlet();
		resourceServlet.doGet(null, null);//202
		
		RSDServlet rSDServlet = new RSDServlet();
		rSDServlet.doGet(null, null);//203
		
		SearchServlet searchServlet = new SearchServlet();
		searchServlet.doGet(null, null);//212
		
		TrackbackServlet trackbackServlet = new TrackbackServlet();
		trackbackServlet.doGet(null, null);//213
		trackbackServlet.doPost(null, null);//222	
	
	 PlanetManager mgr = new JPAPlanetManagerImpl(new JPAPersistenceStrategy());
			 //WebloggerFactory.getWeblogger().getPlanetManager();
     Subscription sub = mgr.getSubscriptionById("ID"); // 227
     new SiteModel().getMostCommentedWeblogs(1,2); //228
     
     RefreshPlanetTask task = new RefreshPlanetTask();
     task.run(); //233
     
     PingQueueTask pingQueueTask = new PingQueueTask();
     pingQueueTask.init();//260
     pingQueueTask.runTask();//247
     
     ResetHitCountsTask resetHitCountsTask = new ResetHitCountsTask();
     resetHitCountsTask.init();//262
     resetHitCountsTask.runTask();//248
     
     ScheduledEntriesTask scheduledEntriesTask = new ScheduledEntriesTask();
     scheduledEntriesTask.init(); //264
     scheduledEntriesTask.runTask();   // 253
     
	}
}

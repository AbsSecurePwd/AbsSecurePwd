package org.apache.roller;



import java.util.ArrayList;
import java.util.List;

import org.apache.roller.planet.business.PlanetManager;
import org.apache.roller.planet.pojos.Subscription;
import org.apache.roller.planet.pojos.SubscriptionEntry;
import org.apache.roller.weblogger.business.WebloggerFactory;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class CaptureOutPutTest {
   
   public static List l;
   private Subscription testSub = null;
   
   public static void main(String[] args) {
	   System.out.println("HERE");
	   l =new ArrayList();
	   Result result = JUnitCore.runClasses(CaptureOutPutTest.class);
	   
	    for (Failure failure : result.getFailures()) {
	       System.out.println(failure.toString());
	    }
			
	    System.out.println(result.wasSuccessful()+" v is:");
	    
	    System.out.println("ListSize: "+l.size());
	   
	    
}
  
  /* @Test
   public final void testMyPrint() {
	   // Prepare to capture output    
	   l.add("One");
	   l.add("two");
	   l.add("three");
	   PrintStream originalOut = System.out;     
	   OutputStream os = new ByteArrayOutputStream();
	   PrintStream ps = new PrintStream(os);
	   System.setOut(ps);
	   // Perform tests
	 //  capture.myPrint("Hello, output!");
	   String s=TestString();
	   
	   System.out.println("TEst: "+s);
	   
	   //assertEquals("Hello, output!", os.toString());
	   // Restore normal operation
	   System.setOut(originalOut);
	   }*/
   
 /*  @Test
   public void getByNameTest(){
	   CustomerDAOImpl obj=new CustomerDAOImpl();
	   obj.getById(738501L);
   }   
   
   
   public String  TestString(){
	   String s="testString";
	   return s;
   }*/
   @Test 
   public void Test1() throws RollerException{
	   PlanetManager mgr = WebloggerFactory.getWeblogger().getPlanetManager();
	   SubscriptionEntry entry = null;
	   SubscriptionEntry testEntry = new SubscriptionEntry();
       testEntry.setPermalink("entryBasics");
       testEntry.setTitle("entryBasics");
       testEntry.setPubTime(new java.sql.Timestamp(System.currentTimeMillis()));
       Subscription sub = mgr.getSubscriptionById(testSub.getId());
       testEntry.setSubscription(sub);
	   
       entry = mgr.getEntryById(testEntry.getId());
   }
   
}

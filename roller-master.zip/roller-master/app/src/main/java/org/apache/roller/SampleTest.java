package org.apache.roller;

import static org.junit.Assert.*;

import org.junit.Test;

public class SampleTest {

	@Test
	public final void testGetConsumerByKey() {
		fail("Not yet implemented"); // TODO
	}

}
